import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonCheckbox, IonButton, AlertController, ModalController } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { cartOutline } from 'ionicons/icons';
import { ModalPage } from '../modal/modal.page';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonCheckbox, IonButton, FormsModule],
})
export class HomePage {

  shoppingList:any[] = [
    {'item':'Broccoli', 'inCart':false},
    {'item':'Bread', 'inCart':false},
    {'item':'Orange Juice', 'inCart':true},
    {'item':'Apples', 'inCart':false}
  ];

  constructor(private alertController:AlertController, private modalController:ModalController) {
    addIcons({ cartOutline });
  }

  async addItem() {
    const alert = await this.alertController.create({
      header: 'What would you like to add?',
      inputs: [
        {
          name: 'item',
          type: 'text',
          placeholder: 'Add an item'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (data) => {
            //No need to do anything
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
            console.log(data);
            this.shoppingList.push({'item':data.item, 'inCart':false});
          }
        }
      ]
    });

    await alert.present();
  }

  async deleteItems() {
    var inputs:any[] = this.shoppingList.map((item:any) => {
      return {name:'toRemove', type:'checkbox', label:item.item, value:item.item};
    });

    const alert = await this.alertController.create({
      header: 'Which would you like to delete?',
      inputs: inputs,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (data) => {
            //No need to do anything
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
            console.log(data);
            this.shoppingList = this.shoppingList.filter((item) => {
              return !data.includes(item.item);
            });
          }
        }
      ]
    });

    await alert.present();
  }

  async checkOut() {
    var boughtItems = this.shoppingList.filter((item:any) => {
      return item.inCart;
    });
    var unboughtItems = this.shoppingList.filter((item:any) => {
      return !item.inCart;
    });
    this.shoppingList = unboughtItems;
    var itemsPurchased = boughtItems.map((item:any) => {
      return item.item;
    });
    const modal = await this.modalController.create({
    component: ModalPage,
    componentProps: {
        'itemsPurchased': itemsPurchased,
      }
    });
    await modal.present();
  }
}
